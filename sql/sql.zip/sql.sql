-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 10.1.21-MariaDB - mariadb.org binary distribution
-- OS Server:                    Win32
-- HeidiSQL Versi:               9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_buku_besar
-- Membuat tabel sementara untuk menangani kesalahan ketergantungan VIEW
CREATE TABLE `akuntansi_buku_besar` (
	`id_voucherjurnal` VARCHAR(13) NULL COLLATE 'latin1_swedish_ci',
	`id_nama_coa` VARCHAR(45) NULL COLLATE 'latin1_swedish_ci',
	`id_detail` INT(18) NOT NULL,
	`id_coa` VARCHAR(9) NOT NULL COLLATE 'latin1_swedish_ci',
	`debit` DECIMAL(10,0) NOT NULL,
	`kredit` DECIMAL(10,0) NOT NULL,
	`id_session` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`nilai_voucher` DECIMAL(11,0) NULL,
	`keterangan` VARCHAR(150) NOT NULL COLLATE 'latin1_swedish_ci',
	`uniqid_voucher` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`eod` DATE NULL,
	`eom` DATE NULL,
	`eoy` YEAR NULL,
	`status_print` TINYINT(3) NULL,
	`waktu` DATE NULL,
	`nama_coa` VARCHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal_special` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci',
	`saldo_awal` DECIMAL(10,0) NULL,
	`nama_kelompok_coa` CHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`nama_kategori` VARCHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`pos` SET('neraca','laba rugi','','') NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal` ENUM('debit','kredit','','') NULL COLLATE 'latin1_swedish_ci',
	`status` TINYINT(1) NULL
) ENGINE=MyISAM;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_coa
-- Membuat tabel sementara untuk menangani kesalahan ketergantungan VIEW
CREATE TABLE `akuntansi_coa` (
	`uniqid` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`pos` SET('neraca','laba rugi','','') NOT NULL COLLATE 'latin1_swedish_ci',
	`nama_kategori` VARCHAR(35) NOT NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal` ENUM('debit','kredit','','') NOT NULL COLLATE 'latin1_swedish_ci',
	`kel_uniqid` VARCHAR(25) NULL COLLATE 'latin1_swedish_ci',
	`id_kelompok_coa` CHAR(8) NULL COLLATE 'latin1_swedish_ci',
	`nama_kelompok_coa` CHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`id_coa` VARCHAR(9) NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal_special` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci',
	`nama_coa` VARCHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`saldo_awal` DECIMAL(10,0) NULL,
	`coa_id` VARCHAR(25) NULL COLLATE 'latin1_swedish_ci'
) ENGINE=MyISAM;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_detail_hutang_piutang
CREATE TABLE IF NOT EXISTS `akuntansi_detail_hutang_piutang` (
  `uniqid` varchar(25) NOT NULL,
  `id_people` char(7) NOT NULL,
  `debit` decimal(10,0) NOT NULL,
  `kredit` decimal(10,0) NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_detail_hutang_piutang: ~0 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_detail_hutang_piutang` DISABLE KEYS */;
/*!40000 ALTER TABLE `akuntansi_detail_hutang_piutang` ENABLE KEYS */;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_detail_stock
CREATE TABLE IF NOT EXISTS `akuntansi_detail_stock` (
  `uniqid` varchar(25) NOT NULL,
  `id_stock` smallint(5) NOT NULL AUTO_INCREMENT,
  `id_vendor` char(7) NOT NULL,
  `debit_stock` int(7) NOT NULL,
  `kredit_stock` int(7) NOT NULL,
  `satuan` char(7) NOT NULL,
  `saldo_quantity_akhir` int(7) NOT NULL,
  `harga_beli` decimal(15,0) NOT NULL,
  `persen_potongan` smallint(3) NOT NULL,
  `nilai_potongan` decimal(7,0) NOT NULL,
  `persen_pajak` smallint(3) NOT NULL,
  `nilai_pajak` decimal(15,0) NOT NULL,
  `total_nilai_stock` decimal(15,0) NOT NULL,
  `keterangan` varchar(35) NOT NULL,
  `uniqid_voucher` varchar(25) NOT NULL,
  `id_jenis_pembayaran` char(7) NOT NULL,
  `id_coa_stock` char(7) DEFAULT NULL,
  PRIMARY KEY (`uniqid`),
  KEY `id_point` (`id_stock`),
  KEY `coa` (`id_coa_stock`),
  KEY `uniqid_voucher` (`uniqid_voucher`),
  CONSTRAINT `akuntansi_detail_stock_ibfk_1` FOREIGN KEY (`uniqid_voucher`) REFERENCES `akuntansi_h_voucher` (`uniqid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `coa` FOREIGN KEY (`id_coa_stock`) REFERENCES `akuntansi_m_coa` (`id_coa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_detail_stock: ~0 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_detail_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `akuntansi_detail_stock` ENABLE KEYS */;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_detail_voucher
CREATE TABLE IF NOT EXISTS `akuntansi_detail_voucher` (
  `uniqid` varchar(25) NOT NULL,
  `uniqid_voucher` varchar(25) NOT NULL,
  `id_detail` int(18) NOT NULL AUTO_INCREMENT,
  `id_user` varchar(18) NOT NULL,
  `id_coa` varchar(9) NOT NULL,
  `debit` decimal(10,0) NOT NULL,
  `kredit` decimal(10,0) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  `id_session` varchar(25) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uniqid`),
  KEY `id_detail` (`id_detail`),
  KEY `detail_akuntansi_voucher_ibfk_1` (`uniqid_voucher`),
  KEY `id_coa` (`id_coa`),
  CONSTRAINT `akuntansi_detail_voucher_ibfk_1` FOREIGN KEY (`id_coa`) REFERENCES `akuntansi_m_coa` (`id_coa`),
  CONSTRAINT `voucher_akunting` FOREIGN KEY (`uniqid_voucher`) REFERENCES `akuntansi_h_voucher` (`uniqid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_detail_voucher: ~0 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_detail_voucher` DISABLE KEYS */;
/*!40000 ALTER TABLE `akuntansi_detail_voucher` ENABLE KEYS */;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_h_voucher
CREATE TABLE IF NOT EXISTS `akuntansi_h_voucher` (
  `uniqid` varchar(25) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `prefix_number` smallint(8) NOT NULL DEFAULT '10000',
  `id_tipe_voucher` char(5) NOT NULL,
  `id_voucher` int(8) NOT NULL AUTO_INCREMENT,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_pembuat` varchar(25) NOT NULL,
  `status_print` tinyint(3) NOT NULL,
  `eod` date NOT NULL,
  `eom` date NOT NULL,
  `eoy` year(4) NOT NULL,
  PRIMARY KEY (`uniqid`),
  KEY `id_voucher` (`id_voucher`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_h_voucher: ~0 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_h_voucher` DISABLE KEYS */;
/*!40000 ALTER TABLE `akuntansi_h_voucher` ENABLE KEYS */;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_kumpulan_jurnal
-- Membuat tabel sementara untuk menangani kesalahan ketergantungan VIEW
CREATE TABLE `akuntansi_kumpulan_jurnal` (
	`uniqid_voucher` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`id_voucher` INT(8) NULL,
	`waktu` TIMESTAMP NOT NULL,
	`eod` DATE NULL,
	`eom` DATE NULL,
	`eoy` YEAR NULL,
	`id_tipe_voucher` CHAR(5) NULL COLLATE 'latin1_swedish_ci',
	`prefix_number` SMALLINT(8) NULL,
	`id_detail` INT(18) NOT NULL,
	`id_coa` VARCHAR(9) NOT NULL COLLATE 'latin1_swedish_ci',
	`nama_coa` VARCHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`nama_kelompok_coa` CHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`nama_kategori` VARCHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal` ENUM('debit','kredit','','') NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal_special` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci',
	`saldo_awal` DECIMAL(10,0) NULL,
	`pos` SET('neraca','laba rugi','','') NULL COLLATE 'latin1_swedish_ci',
	`debit` DECIMAL(10,0) NOT NULL,
	`kredit` DECIMAL(10,0) NOT NULL,
	`id_session` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`keterangan` VARCHAR(150) NOT NULL COLLATE 'latin1_swedish_ci',
	`status` TINYINT(1) NULL,
	`status_print` TINYINT(3) NULL
) ENGINE=MyISAM;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_m_coa
CREATE TABLE IF NOT EXISTS `akuntansi_m_coa` (
  `uniqid` varchar(25) NOT NULL,
  `id_coa` varchar(9) NOT NULL,
  `id_kelompok_coa` char(8) NOT NULL,
  `id_kategori` varchar(11) NOT NULL,
  `nama_coa` varchar(35) NOT NULL,
  `uniqid_sub` varchar(25) NOT NULL,
  `saldo_awal` decimal(10,0) NOT NULL,
  `saldo_normal_special` varchar(1) NOT NULL,
  `quantity` decimal(10,0) NOT NULL,
  PRIMARY KEY (`uniqid`),
  UNIQUE KEY `id_coa` (`id_coa`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_m_coa: ~106 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_m_coa` DISABLE KEYS */;
INSERT INTO `akuntansi_m_coa` (`uniqid`, `id_coa`, `id_kelompok_coa`, `id_kategori`, `nama_coa`, `uniqid_sub`, `saldo_awal`, `saldo_normal_special`, `quantity`) VALUES
	('1', '1011001', '1', '', 'KAS -IDR', '', 0, '', 0),
	('10', '1014003', '4', '', 'Persedian Barang  Arabica Premium', '', 0, '', 0),
	('100', '8000002', '28', '', 'Biaya bunga Bank', '', 0, '', 0),
	('101', '8000003', '28', '', 'Selisih Persedian Barang', '', 0, '', 0),
	('102', '9000000', '30', '', 'Ikhtisar Rugi Laba', '', 0, '', 0),
	('11', '1014004', '4', '', 'Persedian Barang  Arabica Wine', '', 0, '', 0),
	('12', '1014005', '4', '', 'Persedian Barang  Arabica Luwak', '', 0, '', 0),
	('12hpp', '5000000', '24', '', 'HPP', '', 0, '', 0),
	('13', '1014006', '4', '', 'Persedian Barang  Arabica Honey', '', 0, '', 0),
	('14', '1014007', '4', '', 'Persedian Barang  Arabica Full Wash', '', 0, '', 0),
	('15', '1014008', '4', '', 'Persedian Barang  Arabica Semi wash', '', 0, '', 0),
	('16', '1014009', '4', '', 'Persedian Barang  Arabica Blend', '', 0, '', 0),
	('17', '1014010', '4', '', 'Persedian Barang  Robusta', '', 0, '', 0),
	('18', '1014011', '4', '', 'Persedian Barang  Green Coffee', '', 0, '', 0),
	('19', '1014012', '4', '', 'Persedian Barang Tea Tarik ', '', 0, '', 0),
	('2', '1011002', '1', '', 'KAS -USD', '', 0, '', 0),
	('20', '1014013', '4', '', 'Persedian Barang Lemon Tea', '', 0, '', 0),
	('21', '1014014', '4', '', 'Persedian Barang  Coklat', '', 0, '', 0),
	('22', '1014015', '4', '', 'Persedian Barang Sirup ', '', 0, '', 0),
	('23', '1014016', '4', '', 'Persedian Barang Air Mineral', '', 0, '', 0),
	('2322a5ac-0cbf-11e9-b189-7', '100203', '1', '', 'asd', '', 200, '', 0),
	('24', '1014017', '4', '', 'Persedian Barang Air Galon', '', 0, '', 0),
	('25', '1014018', '4', '', 'Persedian Barang Susu Full Cream', '', 0, '', 0),
	('26', '1014019', '4', '', 'Persedian Barang Susu Kental Manis', '', 0, '', 0),
	('27', '1014020', '4', '', 'Persedian Barang Teh Botol Sosro', '', 0, '', 0),
	('28', '1014021', '4', '', 'Persediaan Barang Kemasan Kopi 100 ', '', 0, '', 0),
	('29', '1014022', '4', '', 'Persediaan Barang Kemasan Kopi 250 ', '', 0, '', 0),
	('3', '1012001', '2', '', 'BANK BCA', '', 0, '', 0),
	('30', '1014023', '4', '', 'Persediaan Barang Kemasan Kopi 500 ', '', 0, '', 0),
	('31', '1014024', '4', '', 'Persediaan Barang Kemasan Kopi 1000', '', 0, '', 0),
	('32', '1014025', '4', '', 'Persediaan Barang sticker Kopi Besa', '', 0, '', 0),
	('33', '1014026', '4', '', 'Persediaan Barang sticker Kopi Cup', '', 0, '', 0),
	('34', '1015001', '5', '', 'Sewa Di Bayar Di muka', '', 0, '', 0),
	('35', '1015002', '5', '', 'Uang Muka', '', 0, '', 0),
	('36', '1016001', '6', '', 'Cafe Supllies', '', 0, '', 0),
	('37', '1016002', '6', '', 'Amortisasi Cafe Supplies', '', 0, 'k', 0),
	('38', '1020001', '7', '', 'Perlengkapan & Perabotan Kantor', '', 0, '', 0),
	('39', '1020002', '7', '', 'Akum Penyusutan Perlengkapan & Pera', '', 0, 'k', 0),
	('4', '1012002', '2', '', 'BANK BNI', '', 0, '', 0),
	('40', '1020003', '8', '', 'Peralatan Kantor', '', 0, '', 0),
	('41', '1020004', '8', '', 'Akum Penyusutan Peralatan Kantor', '', 0, 'k', 0),
	('42', '1020005', '9', '', 'Kendaraan', '', 0, '', 0),
	('43', '1020006', '9', '', 'Akum Penyusutan Kendaraan', '', 0, 'k', 0),
	('44', '1020007', '10', '', 'Komputer', '', 0, '', 0),
	('45', '1020008', '10', '', 'Akum Penyusutan Komputer', '', 0, 'k', 0),
	('46', '1020009', '11', '', 'Partisi & Interior', '', 0, '', 0),
	('47', '1020010', '11', '', 'Akum Penyusutan Partisi & Interior', '', 0, 'k', 0),
	('48', '1030001', '12', '', 'Franchise Fee', '', 0, '', 0),
	('49', '1030002', '12', '', 'Goodwill', '', 0, '', 0),
	('5', '1012003', '2', '', 'BANK MANDIRI', '', 0, '', 0),
	('50', '2011001', '14', '', 'Hutang Dagang  A', '', 0, '', 0),
	('51', '2011002', '14', '', 'Hutang Dagang  B', '', 0, '', 0),
	('52', '2011003', '14', '', 'Hutang Dividen', '', 0, '', 0),
	('53', '2012001', '15', '', 'Hutang Karyawan', '', 0, '', 0),
	('54', '2013001', '16', '', 'Hutang PPh ', '', 0, '', 0),
	('55', '2013002', '16', '', 'Hutang PPN', '', 0, '', 0),
	('56', '2021001', '18', '', 'Hutang Bank A', '', 0, '', 0),
	('57', '2021002', '18', '', 'Hutang Bank B', '', 0, '', 0),
	('58', '3010001', '19', '', 'Modal Setor A', '', 0, '', 0),
	('59', '3010002', '19', '', 'Modal Setor B', '', 0, '', 0),
	('6', '1012004', '2', '', 'BANK BSM', '', 0, '', 0),
	('60', '3010003', '19', '', 'Modal Setor C', '', 0, '', 0),
	('61', '3012001', '21', '', 'Laba Rugi di Tahan tahun Lalu', '', 0, '', 0),
	('62', '3012002', '21', '', 'Laba Rugi Bulan Berjalan', '', 0, '', 0),
	('64', '4010001', '22', '', 'Penjualan Makanan', '', 0, '', 0),
	('65', '4010002', '22', '', 'Diskon Penjualan Makanan', '', 0, '', 0),
	('66', '4010003', '22', '', 'Penjualan Minuman', '', 0, '', 0),
	('67', '4010004', '22', '', 'Diskon Penjualan Minuman', '', 0, '', 0),
	('68', '4010005', '22', '', 'Penjualan Bubuk Kopi', '', 0, '', 0),
	('69', '4010006', '22', '', 'Penjualan Snack', '', 0, '', 0),
	('7', '1013001', '3', '', 'PIUTANG DAGANG', '', 0, '', 0),
	('70', '4011001', '23', '', 'Pendapatan Bunga Bank', '', 0, '', 0),
	('71', '6010001', '25', '', 'Biaya Gaji Karyawan', '', 0, '', 0),
	('72', '6010002', '25', '', 'Biaya Tunjangan Karyawan', '', 0, '', 0),
	('73', '6011001', '26', '', 'BIAYA ATK & BARANG CETAKAN', '', 0, '', 0),
	('74', '6011002', '26', '', 'BIAYA KEPERLUAN DAPUR CAFE', '', 0, '', 0),
	('75', '6011003', '26', '', 'BIAYA KEPERLUAN DAPUR MAKANAN', '', 0, '', 0),
	('76', '6011004', '26', '', 'BIAYA KEPERLUAN KANTOR', '', 0, '', 0),
	('77', '6011005', '26', '', 'BIAYA PENDIDIKAN&PELATIHAN', '', 0, '', 0),
	('78', '6011006', '26', '', 'BIAYA TRANSPORTASI', '', 0, '', 0),
	('78a', '1011003', '1', '', 'Kas Kecil', '', 0, '', 0),
	('79', '6011007', '26', '', 'BIAYA PERIZINAN DAN LEGAL', '', 0, '', 0),
	('8', '1014001', '4', '', 'Persedian Barang  Arabica Specialty', '', 0, '', 0),
	('80', '6011008', '26', '', 'BIAYA TELEPON & INTERNET', '', 0, '', 0),
	('81', '6011009', '26', '', 'BIAYA AIR PDAM', '', 0, '', 0),
	('82', '6011010', '26', '', 'BIAYA LISTRIK', '', 0, '', 0),
	('83', '6011011', '26', '', 'BIAYA KURIR DAN EKSPEDISI', '', 0, '', 0),
	('84', '6011012', '26', '', 'BIAYA PROMOSI & IKLAN', '', 0, '', 0),
	('85', '6011013', '26', '', 'BIAYA KEAMANAN & SOSIAL', '', 0, '', 0),
	('86', '6011014', '26', '', 'BIAYA ENTERTAIN', '', 0, '', 0),
	('87', '6011015', '26', '', 'BIAYA PERJALANAN DINAS', '', 0, '', 0),
	('88', '6011016', '26', '', 'BIAYA PEMELIHARAAN DAN PERBAIKAN GE', '', 0, '', 0),
	('89', '6011017', '26', '', 'BIAYA PEMELIHARAAN DAN PERBAIKAN PE', '', 0, '', 0),
	('9', '1014002', '4', '', 'Persedian Barang  Arabica Peaberry', '', 0, '', 0),
	('90', '6011018', '26', '', 'BIAYA PEMELIHARAAN DAN PERLENGKAPAN', '', 0, '', 0),
	('91', '6011019', '29', '', 'Biaya Pajak PPh ', '', 0, '', 0),
	('92', '6011020', '29', '', 'Biaya Pajak PPN', '', 0, '', 0),
	('93', '7000001', '27', '', 'Biaya Amortisasi Cafe Supplies', '', 0, '', 0),
	('94', '7000002', '27', '', 'Biaya Penyusutan Perlengkapan & Per', '', 0, '', 0),
	('95', '7000003', '27', '', 'Biaya Penyusutan Peralatan Kantor', '', 0, '', 0),
	('96', '7000004', '27', '', 'Biaya Penyusutan Kendaraan', '', 0, '', 0),
	('97', '7000005', '27', '', 'Biaya Penyusutan Komputer', '', 0, '', 0),
	('98', '7000006', '27', '', 'Biaya Penyusutan Partisi & Interior', '', 0, '', 0),
	('99', '8000001', '28', '', 'Biaya Adm Bank', '', 0, '', 0),
	('COA5ce3c68c7521d4.1709215', '23423423', '1', '', 'dsfsd', '', 232232, '2', 0),
	('COA5ce3c715ed3756.9025639', '3423423', '1', '', 'werwe', '', 23, '2', 0);
/*!40000 ALTER TABLE `akuntansi_m_coa` ENABLE KEYS */;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_m_kategori
CREATE TABLE IF NOT EXISTS `akuntansi_m_kategori` (
  `uniqid` varchar(25) NOT NULL,
  `id_kategori` varchar(9) NOT NULL,
  `nama_kategori` varchar(35) NOT NULL,
  `pos` set('neraca','laba rugi','','') NOT NULL DEFAULT 'neraca',
  `saldo_normal` enum('debit','kredit','','') NOT NULL,
  PRIMARY KEY (`uniqid`),
  UNIQUE KEY `id_tipe` (`id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_m_kategori: ~15 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_m_kategori` DISABLE KEYS */;
INSERT INTO `akuntansi_m_kategori` (`uniqid`, `id_kategori`, `nama_kategori`, `pos`, `saldo_normal`) VALUES
	('1', '1010000', 'AKTIVA LANCAR', 'neraca', 'debit'),
	('11', '5000000', 'HARGA POKOK PENJUALAN', 'laba rugi', 'debit'),
	('12', '6000000', 'BIAYA OPERASIONAL', 'laba rugi', 'debit'),
	('13', '7000000', 'BIAYA PENYUSUTAN', 'laba rugi', 'debit'),
	('14', '8000000', 'BIAYA LAIN LAIN', 'laba rugi', 'debit'),
	('15', '8010000', 'BIAYA PAJAK', 'laba rugi', 'debit'),
	('16', '9000000', 'IKHTISAR LABA RUGI', 'laba rugi', 'debit'),
	('2', '1020000', 'AKTIVA TETAP', 'neraca', 'debit'),
	('3', '1030000', 'AKTIVA TIDAK BERWUJUD', 'neraca', 'debit'),
	('4', '2010000', 'HUTANG LANCAR', 'neraca', 'kredit'),
	('5', '2020000', 'HUTANGTIDAK LANCAR', 'neraca', 'kredit'),
	('6', '3010000', 'MODAL SETOR', 'neraca', 'kredit'),
	('7', '3011000', 'MODAL SAHAM', 'neraca', 'kredit'),
	('8', '3012000', 'LABA RUGI DI TAHAN', 'neraca', 'kredit'),
	('9', '4010000', 'PENJUALAN', 'laba rugi', 'kredit');
/*!40000 ALTER TABLE `akuntansi_m_kategori` ENABLE KEYS */;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_m_kelompok_coa
CREATE TABLE IF NOT EXISTS `akuntansi_m_kelompok_coa` (
  `uniqid` varchar(25) NOT NULL,
  `id_kelompok_coa` char(8) NOT NULL,
  `id_kategori` char(8) NOT NULL,
  `nama_kelompok_coa` char(35) NOT NULL,
  PRIMARY KEY (`uniqid`),
  UNIQUE KEY `id_subtipe` (`id_kelompok_coa`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_m_kelompok_coa: ~29 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_m_kelompok_coa` DISABLE KEYS */;
INSERT INTO `akuntansi_m_kelompok_coa` (`uniqid`, `id_kelompok_coa`, `id_kategori`, `nama_kelompok_coa`) VALUES
	('1', '1011000', '1', 'KAS'),
	('10', '1020004', '2', 'Komputer'),
	('11', '1020005', '2', 'Partisi & Interior'),
	('12', '1031000', '3', 'Franchise Fee'),
	('13', '1032000', '3', 'Goodwill'),
	('14', '2011000', '4', 'HUTANG DAGANG'),
	('15', '2012000', '4', 'HUTANG LAIN-LAIN'),
	('16', '2013000', '4', 'HUTANG PAJAK'),
	('17', '2020000', '5', 'HUTANGTIDAK LANCAR'),
	('18', '2021000', '5', 'HUTANG BANK'),
	('19', '3010000', '6', 'MODAL SETOR'),
	('2', '1012000', '1', 'BANK'),
	('20', '3011000', '7', 'MODAL SAHAM'),
	('21', '3012000', '8', 'LABA RUGI DI TAHAN'),
	('22', '4010000', '9', 'PENJUALAN'),
	('23', '4011000', '9', 'PENDAPATAN LAIN LAIN'),
	('24', '5000000', '11', 'HARGA POKOK PENJUALAN'),
	('25', '6010000', '12', 'BIAYA GAJI'),
	('26', '6011000', '12', 'BIAYA ADM & UMUM'),
	('27', '7000000', '13', 'BIAYA PENYUSUTAN'),
	('28', '8000000', '14', 'BIAYA LAIN LAIN'),
	('29', '8010000', '15', 'BIAYA PAJAK'),
	('3', '1013000', '1', 'PIUTANG'),
	('30', '9000000', '16', 'IKHTISAR LABA RUGI'),
	('4', '1014000', '1', 'PERSEDIAAN BARANG'),
	('5', '1015000', '1', 'BIAYA DI BAYAR DI MUKA'),
	('7', '1020001', '2', 'Perlengkapan & Perabotan Kantor'),
	('8', '1020002', '2', 'Peralatan Kantor'),
	('9', '1020003', '2', 'Kendaraan');
/*!40000 ALTER TABLE `akuntansi_m_kelompok_coa` ENABLE KEYS */;

-- membuang struktur untuk table akuntansi_percobaan.akuntansi_m_people
CREATE TABLE IF NOT EXISTS `akuntansi_m_people` (
  `uniqid` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_handphone` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  PRIMARY KEY (`uniqid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Membuang data untuk tabel akuntansi_percobaan.akuntansi_m_people: ~5 rows (lebih kurang)
/*!40000 ALTER TABLE `akuntansi_m_people` DISABLE KEYS */;
INSERT INTO `akuntansi_m_people` (`uniqid`, `nama`, `alamat`, `no_handphone`, `email`) VALUES
	('98191786228318210', 'PT. Aceh Sawit Besar', 'Aceh Besar', '0831359599', 'acehsawit@gmail.com'),
	('98191786228318211', 'CV. Medan Sawit Raya', 'Jl. K.L Yos Sudarso Medan', '0831359599', 'medan.sawit@gmail.co'),
	('98216332469731332', 'CV. Karya Wisata Sawit', 'Jl. Karya Wisata', '0834342342', 'karya@gmail.com'),
	('98284808626503680', 'sad', 'dfsd', '323', 'esfsd@gmail.com'),
	('98284808626503681', 'sad', 'dfsd', '323', 'esfsd@gmail.com');
/*!40000 ALTER TABLE `akuntansi_m_people` ENABLE KEYS */;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_trial_balance
-- Membuat tabel sementara untuk menangani kesalahan ketergantungan VIEW
CREATE TABLE `akuntansi_trial_balance` (
	`id_nama_coa` VARCHAR(45) NULL COLLATE 'latin1_swedish_ci',
	`nama_coa` VARCHAR(35) NULL COLLATE 'latin1_swedish_ci',
	`nilai_voucher` DECIMAL(11,0) NULL,
	`nilai_debit` DECIMAL(11,0) NULL,
	`nilai_kredit` DECIMAL(11,0) NULL,
	`eod` DATE NULL,
	`eom` DATE NULL,
	`eoy` YEAR NULL,
	`saldo_normal_special` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci',
	`saldo_normal` ENUM('debit','kredit','','') NULL COLLATE 'latin1_swedish_ci'
) ENGINE=MyISAM;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_buku_besar
-- Menghapus tabel sementara dan menciptakan struktur VIEW terakhir
DROP TABLE IF EXISTS `akuntansi_buku_besar`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `akuntansi_buku_besar` AS SELECT 
        concat(	x.id_tipe_voucher,
				DATE_FORMAT(x.waktu,"%y%m"),
                right(concat(x.prefix_number,x.id_voucher),4))
                as id_voucherjurnal,
        
        CONCAT(`x`.`id_coa`, ' ', `x`.`nama_coa`) AS `id_nama_coa`,
        `x`.`id_detail` AS `id_detail`,
        `x`.`id_coa` AS `id_coa`,
        `x`.`debit` AS `debit`,
        `x`.`kredit` AS `kredit`,
        `x`.`id_session` AS `id_session`,
        (CASE
            WHEN (`x`.`saldo_normal_special` = 'd') THEN (`x`.`debit` - `x`.`kredit`)
            WHEN (`x`.`saldo_normal_special` = 'k') THEN (`x`.`kredit` - `x`.`debit`)
            ELSE IF((`x`.`saldo_normal` = 'debit'),
                (`x`.`debit` - `x`.`kredit`),
                (`x`.`kredit` - `x`.`debit`))
        END) AS `nilai_voucher`,
        `x`.`keterangan` AS `keterangan`,
        `x`.`uniqid_voucher` AS `uniqid_voucher`,
        `x`.`eod` AS `eod`,
        `x`.`eom` AS `eom`,
        `x`.`eoy` AS `eoy`,
        `x`.`status_print` AS `status_print`,
        `x`.`eod` AS `waktu`,
        `x`.`nama_coa` AS `nama_coa`,
        `x`.`saldo_normal_special` AS `saldo_normal_special`,
        `x`.`saldo_awal` AS `saldo_awal`,
        `x`.`nama_kelompok_coa` AS `nama_kelompok_coa`,
        `x`.`nama_kategori` AS `nama_kategori`,
        `x`.`pos` AS `pos`,
        `x`.`saldo_normal` AS `saldo_normal`,
        `x`.`status` AS `status`
    FROM
        `akuntansi_kumpulan_jurnal` `x`
        
    WHERE
        (`x`.`status` = 1) ;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_coa
-- Menghapus tabel sementara dan menciptakan struktur VIEW terakhir
DROP TABLE IF EXISTS `akuntansi_coa`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `akuntansi_coa` AS SELECT
                akuntansi_m_kategori.uniqid,
                akuntansi_m_kategori.pos,
					 akuntansi_m_kategori.nama_kategori,
                akuntansi_m_kategori.saldo_normal,
                akuntansi_m_kelompok_coa.uniqid as kel_uniqid,
                akuntansi_m_kelompok_coa.id_kelompok_coa,
                akuntansi_m_kelompok_coa.nama_kelompok_coa,
                akuntansi_m_coa.id_coa,
                akuntansi_m_coa.saldo_normal_special,
                akuntansi_m_coa.nama_coa,
                akuntansi_m_coa.saldo_awal,
					 akuntansi_m_coa.uniqid as coa_id
                
            FROM
                akuntansi_m_kategori
            LEFT JOIN
                akuntansi_m_kelompok_coa
            ON 
                akuntansi_m_kategori.uniqid = akuntansi_m_kelompok_coa.id_kategori
            LEFT JOIN
                akuntansi_m_coa
            ON
                akuntansi_m_kelompok_coa.uniqid = akuntansi_m_coa.id_kelompok_coa ;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_kumpulan_jurnal
-- Menghapus tabel sementara dan menciptakan struktur VIEW terakhir
DROP TABLE IF EXISTS `akuntansi_kumpulan_jurnal`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `akuntansi_kumpulan_jurnal` AS SELECT 
        `a`.`uniqid_voucher` AS `uniqid_voucher`,
        b.id_voucher,
        `a`.`waktu` AS `waktu`,
        `b`.`eod` AS `eod`,
        b.eom,
        b.eoy,
        b.id_tipe_voucher,
        b.prefix_number,
        `a`.`id_detail` AS `id_detail`,
        `a`.`id_coa` AS `id_coa`,
        `c`.`nama_coa` AS `nama_coa`,
        c.nama_kelompok_coa,
        c.nama_kategori,
        c.saldo_normal,
        c.saldo_normal_special,
        c.saldo_awal,
        c.pos,
        `a`.`debit` AS `debit`,
        `a`.`kredit` AS `kredit`,
        `a`.`id_session` AS `id_session`,
        `a`.`keterangan` AS `keterangan`,
        `b`.`status` AS `status`,
        b.status_print
    FROM
        ((`akuntansi_detail_voucher` `a`
        LEFT JOIN `akuntansi_h_voucher` `b` ON ((`a`.`uniqid_voucher` = `b`.`uniqid`)))
        LEFT JOIN `akuntansi_coa` `c` ON ((`a`.`id_coa` = `c`.`id_coa`))) ;

-- membuang struktur untuk view akuntansi_percobaan.akuntansi_trial_balance
-- Menghapus tabel sementara dan menciptakan struktur VIEW terakhir
DROP TABLE IF EXISTS `akuntansi_trial_balance`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `akuntansi_trial_balance` AS SELECT 
        `id_nama_coa` AS `id_nama_coa`,
        `nama_coa` AS `nama_coa`,
        `nilai_voucher` AS `nilai_voucher`,
        (CASE
            WHEN (`saldo_normal_special` = 'd') THEN `nilai_voucher`
            WHEN (`saldo_normal_special` = 'k') THEN 0
            ELSE IF((`saldo_normal` = 'debit'),
                `nilai_voucher`,
                0)
        END) AS `nilai_debit`,
        (CASE
            WHEN (`saldo_normal_special` = 'd') THEN 0
            WHEN (`saldo_normal_special` = 'k') THEN `nilai_voucher`
            ELSE IF((`saldo_normal` = 'kredit'),
                `nilai_voucher`,
                0)
        END) AS `nilai_kredit`,
        `eod` AS `eod`,
        `eom` AS `eom`,
        `eoy` AS `eoy`,
        `saldo_normal_special` AS `saldo_normal_special`,
        `saldo_normal` AS `saldo_normal`
    FROM
        `akuntansi_buku_besar` ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
